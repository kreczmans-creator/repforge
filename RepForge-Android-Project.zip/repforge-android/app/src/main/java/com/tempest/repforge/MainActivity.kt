package com.tempest.repforge

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import com.google.android.gms.mlkit.codescanner.GmsBarcodeScanning
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.tempest.repforge.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val Ink = Color(0xFF10141C)
private val Panel = Color(0xFF181E29)
private val Panel2 = Color(0xFF202838)
private val Electric = Color(0xFF00AEEF)
private val Purple = Color(0xFF8C71E8)
private val Green = Color(0xFF4FD1A1)
private val Muted = Color(0xFF9AA6B8)
private val Border = Color(0xFF2B3545)

class MainActivity : ComponentActivity() {
    private lateinit var dao: RepForgeDao
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dao = RepForgeDatabase.get(this).dao()
        setContent { RepForgeApp(dao, this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RepForgeApp(dao: RepForgeDao, activity: Activity) {
    var tab by remember { mutableStateOf(0) }
    var caloriesTarget by remember { mutableStateOf("2400") }
    var proteinTarget by remember { mutableStateOf("180") }
    var carbsTarget by remember { mutableStateOf("250") }
    var fatTarget by remember { mutableStateOf("75") }
    val today = LocalDate.now().toString()
    val foods by dao.foodsForDate(today).collectAsStateWithLifecycle(emptyList())
    val logs by dao.workoutLogs().collectAsStateWithLifecycle(emptyList())
    val measurements by dao.measurements().collectAsStateWithLifecycle(emptyList())
    val templates by dao.templates().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var snackbar by remember { mutableStateOf<String?>(null) }


    MaterialTheme(colorScheme = darkColorScheme(
        primary = Electric, onPrimary = Ink, background = Ink, surface = Panel,
        onSurface = Color(0xFFF1F4F9), secondary = Purple, outline = Border
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                Row(Modifier.fillMaxWidth().background(Ink).padding(horizontal=18.dp, vertical=14.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Electric, RoundedCornerShape(10.dp)), contentAlignment=Alignment.Center) {
                        Text("R", fontSize=25.sp, fontWeight=FontWeight.Black, color=Ink)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column {
                        Text("REPFORGE", fontSize=18.sp, fontWeight=FontWeight.Black, letterSpacing=1.8.sp)
                        Text("NUTRITION × STRENGTH", fontSize=9.sp, color=Muted, letterSpacing=1.2.sp)
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor=Panel, contentColor=Muted) {
                    val items = listOf("Home", "Food", "Train", "Progress", "Settings")
                    val icons = listOf(Icons.Default.Dashboard, Icons.Default.Restaurant, Icons.Default.FitnessCenter, Icons.Default.ShowChart, Icons.Default.Tune)
                    items.forEachIndexed { i, label ->
                        NavigationBarItem(selected=tab==i, onClick={tab=i}, icon={Icon(icons[i], contentDescription=label)}, label={Text(label, fontSize=10.sp)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Electric, selectedTextColor=Electric, indicatorColor=Panel2, unselectedIconColor=Muted, unselectedTextColor=Muted))
                    }
                }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)) {
                when(tab) {
                    0 -> HomeScreen(foods, caloriesTarget.toDoubleOrNull()?:2400.0, proteinTarget.toDoubleOrNull()?:180.0, carbsTarget.toDoubleOrNull()?:250.0, fatTarget.toDoubleOrNull()?:75.0, templates, measurements, logs, onGoFood={tab=1}, onGoTrain={tab=2})
                    1 -> FoodScreen(dao, foods, today, activity, onScan={
                        try {
                            val task = GmsBarcodeScanning.getClient(activity).startScan()
                            task.addOnSuccessListener { barcode ->
                                val code = barcode.rawValue
                                if (!code.isNullOrBlank()) scope.launch {
                                    try {
                                        val p = OpenFoodFacts.barcode(code)
                                        if (p != null) dao.insertFood(NutritionEntry(date=today, meal="Snacks", name=p.name, calories=p.kcalPer100g, protein=p.proteinPer100g, carbs=p.carbsPer100g, fat=p.fatPer100g, servingNote="per 100 g", barcode=code))
                                        else snackbar="Barcode not found"
                                    } catch (_: Exception) { snackbar="Barcode lookup failed" }
                                }
                            }.addOnFailureListener { snackbar="Barcode scan cancelled or unavailable" }
                        } catch (_: Exception) { snackbar="Barcode scanner unavailable on this device" }
                    }, notify={snackbar=it})
                    2 -> TrainingScreen(dao, templates, logs, notify={snackbar=it})
                    3 -> ProgressScreen(dao, measurements, notify={snackbar=it})
                    else -> SettingsScreen(caloriesTarget, {caloriesTarget=it}, proteinTarget,{proteinTarget=it}, carbsTarget,{carbsTarget=it},fatTarget,{fatTarget=it})
                }
            }
        }
    }
}

@Composable fun ScreenTitle(kicker:String, title:String) {
    Spacer(Modifier.height(14.dp)); Text(kicker.uppercase(), color=Electric, fontSize=10.sp, letterSpacing=1.7.sp, fontWeight=FontWeight.Bold)
    Text(title, fontSize=31.sp, fontWeight=FontWeight.Bold, letterSpacing=(-.6).sp)
    Spacer(Modifier.height(12.dp))
}
@Composable fun PanelCard(content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom=12.dp).background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), content=content)
}
@Composable fun SectionTitle(title:String, action:String?=null, onAction:(()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(top=8.dp,bottom=10.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
        Text(title, fontSize=17.sp, fontWeight=FontWeight.SemiBold)
        if(action!=null && onAction!=null) TextButton(onClick=onAction, contentPadding=PaddingValues(0.dp)) { Text(action, color=Electric) }
    }
}
@Composable fun MacroBar(label:String, amount:Double, target:Double, color:Color) {
    Column(Modifier.padding(vertical=6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text(label, color=Muted, fontSize=12.sp); Text("${amount.toInt()} / ${target.toInt()} g", fontSize=12.sp, fontWeight=FontWeight.SemiBold)
        }
        Spacer(Modifier.height(5.dp)); Box(Modifier.fillMaxWidth().height(6.dp).background(Panel2, CircleShape)) {
            Box(Modifier.fillMaxWidth((if(target>0)(amount/target).coerceIn(0.0,1.0).toFloat() else 0f)).fillMaxHeight().background(color, CircleShape))
        }
    }
}
@Composable fun HomeScreen(foods:List<NutritionEntry>, calTarget:Double, pTarget:Double, cTarget:Double, fTarget:Double, templates:List<WorkoutTemplate>, measurements:List<MeasurementEntry>, logs:List<WorkoutLog>, onGoFood:()->Unit,onGoTrain:()->Unit) {
    val calories=foods.sumOf{it.calories}; val protein=foods.sumOf{it.protein}; val carbs=foods.sumOf{it.carbs}; val fat=foods.sumOf{it.fat}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM")).uppercase(),"Your cockpit.")
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            PanelCard { Text("CALORIES", color=Muted, fontSize=10.sp, letterSpacing=1.sp); Text("${(calTarget-calories).toInt()}", fontSize=30.sp, fontWeight=FontWeight.Bold); Text("kcal remaining", color=Muted, fontSize=11.sp); Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress={(calories/calTarget).coerceIn(0.0,1.0).toFloat()}, color=Electric, trackColor=Panel2, modifier=Modifier.fillMaxWidth()); Text("${calories.toInt()} eaten · ${calTarget.toInt()} target", color=Muted, fontSize=10.sp) }
            PanelCard { Text("PROTEIN", color=Muted, fontSize=10.sp, letterSpacing=1.sp); Text("${protein.toInt()} g", fontSize=30.sp, fontWeight=FontWeight.Bold); Text("of ${pTarget.toInt()} g target", color=Muted, fontSize=11.sp); Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress={(protein/pTarget).coerceIn(0.0,1.0).toFloat()}, color=Purple, trackColor=Panel2, modifier=Modifier.fillMaxWidth()) }
        }
        PanelCard { Text("MACROS", fontSize=11.sp, letterSpacing=1.2.sp, color=Muted); MacroBar("Protein",protein,pTarget,Purple); MacroBar("Carbohydrates",carbs,cTarget,Electric); MacroBar("Fat",fat,fTarget,Green) }
        SectionTitle("Today's food diary","Add food",onGoFood)
        PanelCard { if(foods.isEmpty()) Text("Nothing logged yet. Add your first meal.",color=Muted) else foods.forEach { Text(it.name,fontWeight=FontWeight.Medium); Text("${it.meal} · ${it.calories.toInt()} kcal · P ${it.protein.toInt()}g / C ${it.carbs.toInt()}g / F ${it.fat.toInt()}g",fontSize=11.sp,color=Muted); HorizontalDivider(color=Border); Spacer(Modifier.height(5.dp)) } }
        SectionTitle("Next session","Open training",onGoTrain)
        PanelCard { val t=templates.firstOrNull(); if(t==null) Text("Create your first workout template in Training.",color=Muted) else { Text("${t.programmeName} · ${t.workoutName}",fontWeight=FontWeight.SemiBold); Text(t.exercises.lines().joinToString(" · "){it.substringBefore("|")},color=Muted,fontSize=12.sp) } }
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            PanelCard { Text("LATEST WEIGHT",color=Muted,fontSize=10.sp); Text(measurements.lastOrNull{it.weightKg!=null}?.let{"${it.weightKg} kg"}?: "—",fontSize=24.sp,fontWeight=FontWeight.Bold) }
            PanelCard { Text("WORKOUTS LOGGED",color=Muted,fontSize=10.sp); Text("${logs.size}",fontSize=24.sp,fontWeight=FontWeight.Bold) }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)\n@Composable fun FoodScreen(dao:RepForgeDao, foods:List<NutritionEntry>, today:String, activity:Activity, onScan:()->Unit, notify:(String)->Unit) {
    var query by remember { mutableStateOf("") }; var results by remember { mutableStateOf<List<FoodProduct>>(emptyList()) }; var searching by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }; var kcal by remember { mutableStateOf("") }; var protein by remember { mutableStateOf("") }; var carbs by remember { mutableStateOf("") }; var fat by remember { mutableStateOf("") }; var meal by remember { mutableStateOf("Breakfast") }; var servings by remember { mutableStateOf("1") }
    val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Fuel the work","Nutrition.")
        PanelCard {
            Text("FOOD DATABASE",color=Muted,fontSize=10.sp,letterSpacing=1.sp); Spacer(Modifier.height(8.dp))
            OutlinedTextField(query,{query=it},label={Text("Search food or brand")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={if(query.isNotBlank()){searching=true;scope.launch { try { results=OpenFoodFacts.search(query); if(results.isEmpty())notify("No results found") } catch(_:Exception){notify("Food search failed. Check your connection")} finally{searching=false} }}},modifier=Modifier.weight(1f)) { Text(if(searching)"Searching…" else "Search") }
                OutlinedButton(onClick=onScan,modifier=Modifier.weight(1f)) { Icon(Icons.Default.QrCodeScanner,null); Spacer(Modifier.width(5.dp)); Text("Scan barcode") }
            }
            results.forEach { p ->
                HorizontalDivider(color=Border)
                Row(Modifier.fillMaxWidth().padding(vertical=9.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(p.name,fontWeight=FontWeight.SemiBold); Text("${p.brand} · ${p.kcalPer100g.toInt()} kcal/100g",color=Muted,fontSize=11.sp) }
                    TextButton(onClick={scope.launch { dao.insertFood(NutritionEntry(date=today,meal=meal,name=p.name,calories=p.kcalPer100g,protein=p.proteinPer100g,carbs=p.carbsPer100g,fat=p.fatPer100g,servingNote="per 100 g",barcode=p.barcode));notify("Added per 100 g; adjust portion as needed") }}) { Text("Add") }
                }
            }
            Text("Product data is crowdsourced. Verify the label and serving size.",color=Muted,fontSize=10.sp)
        }
        PanelCard {
            Text("QUICK ADD",color=Muted,fontSize=10.sp,letterSpacing=1.sp); Spacer(Modifier.height(8.dp))
            OutlinedTextField(name,{name=it},label={Text("Food name")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedTextField(kcal,{kcal=it},label={Text("kcal")},modifier=Modifier.weight(1f)); OutlinedTextField(protein,{protein=it},label={Text("Protein g")},modifier=Modifier.weight(1f)) }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedTextField(carbs,{carbs=it},label={Text("Carbs g")},modifier=Modifier.weight(1f)); OutlinedTextField(fat,{fat=it},label={Text("Fat g")},modifier=Modifier.weight(1f)) }
            OutlinedTextField(servings,{servings=it},label={Text("Servings")},modifier=Modifier.fillMaxWidth())
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) {
                OutlinedTextField(value=meal, onValueChange={}, label={Text("Meal")}, modifier=Modifier.fillMaxWidth().menuAnchor(), readOnly=true, trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
                ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { listOf("Breakfast","Lunch","Dinner","Snacks").forEach { DropdownMenuItem(text={Text(it)},onClick={meal=it;expanded=false}) } }
            }
            Button(onClick={if(name.isBlank()){notify("Enter a food name")}else{val s=(servings.toDoubleOrNull()?:1.0).coerceAtLeast(.1);scope.launch{dao.insertFood(NutritionEntry(date=today,meal=meal,name=name,calories=(kcal.toDoubleOrNull()?:0.0)*s,protein=(protein.toDoubleOrNull()?:0.0)*s,carbs=(carbs.toDoubleOrNull()?:0.0)*s,fat=(fat.toDoubleOrNull()?:0.0)*s,servingNote="$s serving(s)"));name="";kcal="";protein="";carbs="";fat="";servings="1";notify("Food added")}}},modifier=Modifier.fillMaxWidth()) { Text("Add to diary") }
        }
        PanelCard { Text("TODAY'S DIARY",fontWeight=FontWeight.SemiBold); Spacer(Modifier.height(8.dp)); if(foods.isEmpty()) Text("No food entries yet",color=Muted) else foods.forEach { f -> Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(f.name); Text("${f.meal} · P ${f.protein.toInt()}g · C ${f.carbs.toInt()}g · F ${f.fat.toInt()}g",color=Muted,fontSize=10.sp) }; Column(horizontalAlignment=Alignment.End) { Text("${f.calories.toInt()} kcal",fontWeight=FontWeight.SemiBold); TextButton(onClick={scope.launch{dao.deleteFood(f)}}){Text("Remove",color=Color(0xFFFF6D7A))} } }; HorizontalDivider(color=Border) } }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable fun TrainingScreen(dao:RepForgeDao,templates:List<WorkoutTemplate>,logs:List<WorkoutLog>,notify:(String)->Unit) {
    var programme by remember { mutableStateOf("My programme") }; var workout by remember { mutableStateOf("Full Body A") }; var exerciseText by remember { mutableStateOf("Squat|3|5\nBench press|3|5\nBarbell row|3|8") }
    var selected by remember { mutableStateOf<Long?>(null) }; var weights by remember { mutableStateOf(mapOf<String,String>()) }; var notes by remember { mutableStateOf("") }
    val scope=rememberCoroutineScope(); val template=templates.firstOrNull{it.id==selected}?:templates.firstOrNull()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Progressive overload","Training.")
        PanelCard {
            Text("PROGRAMME BUILDER",color=Muted,fontSize=10.sp,letterSpacing=1.sp)
            OutlinedTextField(programme,{programme=it},label={Text("Programme name")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(workout,{workout=it},label={Text("Workout name")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(exerciseText,{exerciseText=it},label={Text("Exercises: one per line — Name | sets | reps")},modifier=Modifier.fillMaxWidth().heightIn(min=120.dp),minLines=3)
            Text("Example: Squat | 3 | 5",color=Muted,fontSize=10.sp)
            Button(onClick={val cleaned=exerciseText.lines().mapNotNull { line -> val parts=line.split("|").map{it.trim()}; if(parts[0].isBlank())null else "${parts[0]}|${parts.getOrNull(1)?.toIntOrNull()?.coerceIn(1,20)?:3}|${parts.getOrNull(2)?.toIntOrNull()?.coerceIn(1,100)?:8}" };if(cleaned.isEmpty())notify("Add at least one exercise")else scope.launch{dao.insertTemplate(WorkoutTemplate(programmeName=programme,workoutName=workout,exercises=cleaned.joinToString("\n")));notify("Workout template saved")}},modifier=Modifier.fillMaxWidth()){Text("Save workout template")}
        }
        PanelCard {
            Text("START SESSION",color=Muted,fontSize=10.sp,letterSpacing=1.sp)
            if(templates.isEmpty()) Text("Save a workout template to begin.",color=Muted) else {
                templates.forEach { t -> Row(verticalAlignment=Alignment.CenterVertically) { RadioButton(selected=(template?.id==t.id),onClick={selected=t.id}); Column { Text("${t.programmeName} · ${t.workoutName}",fontWeight=FontWeight.SemiBold); Text(t.exercises.lines().joinToString(" · "){it.substringBefore("|")},fontSize=11.sp,color=Muted) } } }
                template?.let { t ->
                    Spacer(Modifier.height(8.dp)); Text("Record working sets",fontWeight=FontWeight.SemiBold)
                    t.exercises.lines().forEachIndexed { index,line ->
                        val p=line.split("|"); val ex=p[0]; val sets=p.getOrNull(1)?.toIntOrNull()?:3; val reps=p.getOrNull(2)?.toIntOrNull()?:8
                        Text("$ex · $sets × $reps",color=Electric,fontWeight=FontWeight.Medium,modifier=Modifier.padding(top=8.dp))
                        repeat(sets) { set -> val key="$index-$set"; OutlinedTextField(weights[key]?: "",{weights=weights+(key to it)},label={Text("Set ${set+1} weight (kg)")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
                    }
                    OutlinedTextField(notes,{notes=it},label={Text("Session notes (optional)")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={val summary=t.exercises.lines().mapIndexed { i,l -> val p=l.split("|"); "${p[0]}: "+(0 until (p.getOrNull(1)?.toIntOrNull()?:3)).joinToString(", ") { s -> "${weights["$i-$s"].orEmpty().ifBlank{"—"} } kg × ${p.getOrNull(2)?:8}" } }.joinToString("; ");scope.launch{dao.insertWorkout(WorkoutLog(date=LocalDate.now().toString(),workoutName=t.workoutName,exerciseSummary=summary,completedSets=weights.count{it.value.isNotBlank()},notes=notes));weights=emptyMap();notes="";notify("Workout saved to history")}},modifier=Modifier.fillMaxWidth()){Text("Finish and save workout")}
                }
            }
        }
        PanelCard { Text("WORKOUT HISTORY",fontWeight=FontWeight.SemiBold); if(logs.isEmpty())Text("Your sessions will appear here.",color=Muted) else logs.forEach { l -> HorizontalDivider(color=Border); Spacer(Modifier.height(8.dp)); Text("${l.date} · ${l.workoutName}",fontWeight=FontWeight.SemiBold); Text("${l.completedSets} sets with weights recorded",color=Muted,fontSize=11.sp); Text(l.exerciseSummary,fontSize=12.sp); if(l.notes.isNotBlank())Text(l.notes,color=Muted,fontSize=11.sp) } }
        Spacer(Modifier.height(20.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)\n@Composable fun ProgressScreen(dao:RepForgeDao,measurements:List<MeasurementEntry>,notify:(String)->Unit) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }; var weight by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    val fields=listOf("Neck (cm)","Chest (cm)","Waist (cm)","Hips (cm)","Right thigh (cm)","Left thigh (cm)","Right calf (cm)","Left calf (cm)","Right biceps (cm)","Left biceps (cm)","Right forearm (cm)","Left forearm (cm)")
    var values by remember { mutableStateOf(List(12){""}) }; var metric by remember { mutableStateOf("Weight (kg)") }
    val scope=rememberCoroutineScope()
    val metricValues:List<Pair<String,Double>> = when(metric) {
        "Weight (kg)" -> measurements.mapNotNull{m->m.weightKg?.let{m.date to it}}
        "Waist (cm)" -> measurements.mapNotNull{m->m.waistCm?.let{m.date to it}}
        "Chest (cm)" -> measurements.mapNotNull{m->m.chestCm?.let{m.date to it}}
        "Hips (cm)" -> measurements.mapNotNull{m->m.hipsCm?.let{m.date to it}}
        "Neck (cm)" -> measurements.mapNotNull{m->m.neckCm?.let{m.date to it}}
        "Right thigh (cm)" -> measurements.mapNotNull{m->m.thighRightCm?.let{m.date to it}}
        "Left thigh (cm)" -> measurements.mapNotNull{m->m.thighLeftCm?.let{m.date to it}}
        "Right calf (cm)" -> measurements.mapNotNull{m->m.calfRightCm?.let{m.date to it}}
        "Left calf (cm)" -> measurements.mapNotNull{m->m.calfLeftCm?.let{m.date to it}}
        "Right biceps (cm)" -> measurements.mapNotNull{m->m.bicepsRightCm?.let{m.date to it}}
        "Left biceps (cm)" -> measurements.mapNotNull{m->m.bicepsLeftCm?.let{m.date to it}}
        "Right forearm (cm)" -> measurements.mapNotNull{m->m.forearmRightCm?.let{m.date to it}}
        else -> measurements.mapNotNull{m->m.forearmLeftCm?.let{m.date to it}}
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Measure what matters","Progress.")
        PanelCard {
            Text("LOG MEASUREMENTS",color=Muted,fontSize=10.sp,letterSpacing=1.sp)
            OutlinedTextField(date,{date=it},label={Text("Date (YYYY-MM-DD)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(weight,{weight=it},label={Text("Weight (kg)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            fields.forEachIndexed { i, label -> OutlinedTextField(values[i],{v->values=values.toMutableList().also{it[i]=v}},label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true) }
            OutlinedTextField(notes,{notes=it},label={Text("Notes")},modifier=Modifier.fillMaxWidth())
            Button(onClick={val parsed=values.map{it.toDoubleOrNull()};if(weight.isBlank()&&parsed.all{it==null})notify("Enter at least one measurement")else scope.launch{dao.insertMeasurement(MeasurementEntry(date=date,weightKg=weight.toDoubleOrNull(),neckCm=parsed[0],chestCm=parsed[1],waistCm=parsed[2],hipsCm=parsed[3],thighRightCm=parsed[4],thighLeftCm=parsed[5],calfRightCm=parsed[6],calfLeftCm=parsed[7],bicepsRightCm=parsed[8],bicepsLeftCm=parsed[9],forearmRightCm=parsed[10],forearmLeftCm=parsed[11],notes=notes));weight="";values=List(12){""};notes="";notify("Measurements saved")}},modifier=Modifier.fillMaxWidth()){Text("Save measurements")}
        }
        PanelCard {
            Text("TREND CHART",fontWeight=FontWeight.SemiBold)
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) {
                OutlinedTextField(value=metric, onValueChange={}, label={Text("Metric")}, modifier=Modifier.fillMaxWidth().menuAnchor(), readOnly=true, trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
                ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { listOf("Weight (kg)","Neck (cm)","Chest (cm)","Waist (cm)","Hips (cm)","Right thigh (cm)","Left thigh (cm)","Right calf (cm)","Left calf (cm)","Right biceps (cm)","Left biceps (cm)","Right forearm (cm)","Left forearm (cm)").forEach { DropdownMenuItem(text={Text(it)},onClick={metric=it;expanded=false}) } }
            }
            Spacer(Modifier.height(12.dp))
            if(metricValues.isEmpty()) Text("Add measurements to build this trend.",color=Muted) else {
                val vals=metricValues.map{it.second}; val min=vals.minOrNull()!!; val max=vals.maxOrNull()!!; val span=(max-min).takeIf{it>0}?:1.0
                Canvas(Modifier.fillMaxWidth().height(190.dp)) {
                    val left=28f; val right=size.width-8f; val top=10f; val bottom=size.height-24f
                    repeat(5){i->val y=top+(bottom-top)*i/4;drawLine(Border,Offset(left,y),Offset(right,y),1f)}
                    val pts=vals.mapIndexed{i,v->Offset(if(vals.size==1)(left+right)/2 else left+(right-left)*i/(vals.size-1),bottom-((v-min)/span).toFloat()*(bottom-top))}
                    pts.zipWithNext().forEach{(a,b)->drawLine(Electric,a,b,3f,cap=StrokeCap.Round)}
                    pts.forEach{drawCircle(Electric,4f,it)}
                }
                Text("${metricValues.first().first} → ${metricValues.last().first} · ${metricValues.size} entries · ${min}–${max}",fontSize=10.sp,color=Muted)
            }
        }
        PanelCard { Text("HISTORY",fontWeight=FontWeight.SemiBold); if(measurements.isEmpty()) Text("No measurements logged.",color=Muted) else measurements.asReversed().forEach { m -> Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(m.date,fontWeight=FontWeight.SemiBold); Text(listOfNotNull(m.weightKg?.let{"${it} kg"},m.waistCm?.let{"waist ${it} cm"},m.chestCm?.let{"chest ${it} cm"}).joinToString(" · "),fontSize=11.sp,color=Muted); if(m.notes.isNotBlank())Text(m.notes,fontSize=11.sp,color=Muted) }; TextButton(onClick={scope.launch{dao.deleteMeasurement(m.id)}}){Text("Delete",color=Color(0xFFFF6D7A))} }; HorizontalDivider(color=Border) } }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable fun SettingsScreen(calories:String,onCalories:(String)->Unit,protein:String,onProtein:(String)->Unit,carbs:String,onCarbs:(String)->Unit,fat:String,onFat:(String)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Your baseline","Settings.")
        PanelCard {
            Text("DAILY TARGETS",color=Muted,fontSize=10.sp,letterSpacing=1.sp)
            OutlinedTextField(calories,onCalories,label={Text("Calories (kcal)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(protein,onProtein,label={Text("Protein (g)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(carbs,onCarbs,label={Text("Carbohydrates (g)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(fat,onFat,label={Text("Fat (g)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Text("Targets are editable during this session. Persistent target settings and nutrition recommendations are planned for the next iteration.",fontSize=11.sp,color=Muted)
        }
        PanelCard {
            Text("LOCAL-FIRST STORAGE",fontWeight=FontWeight.SemiBold)
            Text("Food entries, workouts, templates and measurements are saved in an on-device Room database. This native prototype does not yet provide account sign-in, cloud sync or backup/export.",color=Muted,fontSize=12.sp)
            Spacer(Modifier.height(8.dp)); Text("RepForge Android · v0.1.0",color=Electric,fontSize=11.sp)
        }
    }
}
