package com.tempest.repforge.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "nutrition_entries")
data class NutritionEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val meal: String,
    val name: String,
    val calories: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val servingNote: String = "1 serving",
    val barcode: String? = null
)

@Entity(tableName = "workout_logs")
data class WorkoutLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val workoutName: String,
    val exerciseSummary: String,
    val completedSets: Int,
    val notes: String = ""
)

@Entity(tableName = "measurements")
data class MeasurementEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val weightKg: Double? = null,
    val neckCm: Double? = null,
    val chestCm: Double? = null,
    val waistCm: Double? = null,
    val hipsCm: Double? = null,
    val thighRightCm: Double? = null,
    val thighLeftCm: Double? = null,
    val calfRightCm: Double? = null,
    val calfLeftCm: Double? = null,
    val bicepsRightCm: Double? = null,
    val bicepsLeftCm: Double? = null,
    val forearmRightCm: Double? = null,
    val forearmLeftCm: Double? = null,
    val notes: String = ""
)

@Entity(tableName = "workout_templates")
data class WorkoutTemplate(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val programmeName: String,
    val workoutName: String,
    // One exercise per line: Exercise name|sets|reps
    val exercises: String
)

@Dao
interface RepForgeDao {
    @Query("SELECT * FROM nutrition_entries WHERE date = :date ORDER BY id DESC")
    fun foodsForDate(date: String): Flow<List<NutritionEntry>>
    @Query("SELECT * FROM nutrition_entries ORDER BY date DESC, id DESC")
    fun allFoods(): Flow<List<NutritionEntry>>
    @Insert suspend fun insertFood(entry: NutritionEntry)
    @Delete suspend fun deleteFood(entry: NutritionEntry)

    @Query("SELECT * FROM workout_logs ORDER BY date DESC, id DESC")
    fun workoutLogs(): Flow<List<WorkoutLog>>
    @Insert suspend fun insertWorkout(log: WorkoutLog)

    @Query("SELECT * FROM measurements ORDER BY date ASC")
    fun measurements(): Flow<List<MeasurementEntry>>
    @Insert suspend fun insertMeasurement(entry: MeasurementEntry)
    @Query("DELETE FROM measurements WHERE id = :id")
    suspend fun deleteMeasurement(id: Long)

    @Query("SELECT * FROM workout_templates ORDER BY id ASC")
    fun templates(): Flow<List<WorkoutTemplate>>
    @Insert suspend fun insertTemplate(template: WorkoutTemplate)
    @Delete suspend fun deleteTemplate(template: WorkoutTemplate)
}

@Database(
    entities = [NutritionEntry::class, WorkoutLog::class, MeasurementEntry::class, WorkoutTemplate::class],
    version = 1,
    exportSchema = false
)
abstract class RepForgeDatabase : RoomDatabase() {
    abstract fun dao(): RepForgeDao
    companion object {
        @Volatile private var INSTANCE: RepForgeDatabase? = null
        fun get(context: Context): RepForgeDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, RepForgeDatabase::class.java, "repforge.db")
                .fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
